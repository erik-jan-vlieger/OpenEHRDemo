#!/usr/bin/env python3
"""
fix_opt14.py — Transform Archie 3.x AOM 2 OPT output to valid OPT 1.4 XML.

Archie 3.x internally works with AOM 2 objects and its JAXB serializer
produces AOM 2 XML — even when the input archetypes were ADL 1.4.
EHRbase expects OPT 1.4 XML (namespace http://schemas.openehr.org/v1,
root element <template>).

This script:
1. Rewrites the root element from <operationaltemplate>/<operationalTemplate>
   to <template> with correct OPT 1.4 namespace
2. Strips AOM 2-specific expression elements from ARCHETYPE_SLOT includes/excludes
   (binaryOperator, modelReference, operatorDefBuiltin, unaryOperator, constraint)
3. Converts ARCHETYPE_SLOT includes/excludes to OPT 1.4 ASSERTION format
4. Fixes namespace declarations and xsi:type values
5. Cleans up AOM 2-only elements that have no OPT 1.4 equivalent

Usage:
    python3 scripts/fix_opt14.py opts/
    python3 scripts/fix_opt14.py opts/Wound_Assessment_Sensire.v1.opt

The script modifies files in-place and creates .bak backups.
"""

import sys
import os
import re
import shutil
from pathlib import Path
import xml.etree.ElementTree as ET

# OPT 1.4 namespace
NS_OPT14 = "http://schemas.openehr.org/v1"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"

# AOM 2 elements that don't exist in OPT 1.4 XSD
AOM2_EXPRESSION_ELEMENTS = {
    'binaryOperator', 'unaryOperator', 'modelReference',
    'operatorDefBuiltin', 'operatorDef',
    'leftOperand', 'rightOperand', 'operand',
    'referenceType', 'path', 'type',
}

# AOM 2 elements in ARCHETYPE_SLOT that need special handling
AOM2_SLOT_CHILD_ELEMENTS = {
    'binaryOperator', 'unaryOperator', 'constraint',
}


def fix_opt14(filepath):
    """Fix a single OPT file from AOM 2 to OPT 1.4 format."""
    print(f"\n  Verwerken: {filepath.name}")

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Detect what we're working with
    is_aom2 = False
    issues = []

    for term in ['binaryOperator', 'modelReference', 'operatorDefBuiltin',
                 'unaryOperator', 'operand']:
        if term in content:
            is_aom2 = True
            issues.append(term)

    if not is_aom2:
        # Check namespace
        if NS_OPT14 in content and '<template' in content.lower():
            print(f"    ✓ Lijkt al OPT 1.4 — overgeslagen")
            return True
        elif not issues:
            # Might just need namespace fix
            pass

    # Create backup
    backup = filepath.with_suffix('.opt.bak')
    shutil.copy2(filepath, backup)

    # Strategy: work with raw XML string manipulation + ET for structural changes.
    # ET loses comments and can mangle namespaces, so we use a hybrid approach.

    modified = content
    changes = []

    # === Fix 1: Root element and namespace ===
    # Archie may output <operationaltemplate> or <operationalTemplate>
    # OPT 1.4 expects <template xmlns="http://schemas.openehr.org/v1">

    # Replace root element opening tag
    root_patterns = [
        (r'<operationaltemplate\b', '<template'),
        (r'<operationalTemplate\b', '<template'),
        (r'<OperationalTemplate\b', '<template'),
    ]
    for pattern, replacement in root_patterns:
        if re.search(pattern, modified, re.IGNORECASE):
            modified = re.sub(pattern, replacement, modified, count=1, flags=re.IGNORECASE)
            changes.append("Root element → <template>")
            break

    # Replace closing root element
    close_patterns = [
        (r'</operationaltemplate\s*>', '</template>'),
        (r'</operationalTemplate\s*>', '</template>'),
        (r'</OperationalTemplate\s*>', '</template>'),
    ]
    for pattern, replacement in close_patterns:
        if re.search(pattern, modified, re.IGNORECASE):
            modified = re.sub(pattern, replacement, modified, count=1, flags=re.IGNORECASE)
            break

    # === Fix 2: Ensure correct namespace ===
    # Add xmlns="http://schemas.openehr.org/v1" if not present
    if NS_OPT14 not in modified:
        # Add namespace to root element
        modified = re.sub(
            r'<template\b',
            f'<template xmlns="{NS_OPT14}"',
            modified, count=1
        )
        changes.append(f"Namespace → {NS_OPT14}")
    
    # Ensure xsi namespace is declared
    if NS_XSI not in modified:
        modified = re.sub(
            r'<template\b([^>]*?)>',
            f'<template\\1 xmlns:xsi="{NS_XSI}">',
            modified, count=1
        )

    # === Fix 3: Strip AOM 2 expression trees from ARCHETYPE_SLOT includes/excludes ===
    # In OPT 1.4, includes/excludes contain simple string expressions, not AOM 2 objects.
    # We replace AOM 2 expression trees with the OPT 1.4 equivalent.
    # 
    # AOM 2 pattern:
    #   <includes>
    #     <binaryOperator>
    #       <leftOperand><modelReference>...</modelReference></leftOperand>
    #       <rightOperand><constraint>...</constraint></rightOperand>
    #     </binaryOperator>
    #   </includes>
    #
    # OPT 1.4 pattern:
    #   <includes>
    #     <string_expression>archetype_id/value matches {/.*/}</string_expression>
    #   </includes>
    #
    # Since in an OPT all slots are already resolved, the safest approach is to
    # replace all slot includes/excludes with the permissive wildcard.

    # Remove entire content of <includes> and <excludes> within ARCHETYPE_SLOT contexts
    # and replace with OPT 1.4 string_expression

    def replace_slot_assertions(xml_str):
        """Replace AOM 2 slot assertions with OPT 1.4 format."""
        count = 0

        # Pattern: <includes>...AOM2 content...</includes>
        # Replace with OPT 1.4 assertion format
        def fix_includes(match):
            nonlocal count
            inner = match.group(1)
            # Only fix if it contains AOM 2 elements
            if any(elem in inner for elem in AOM2_SLOT_CHILD_ELEMENTS):
                count += 1
                return (
                    '<includes>\n'
                    '              <string_expression>archetype_id/value matches {/.*/ }</string_expression>\n'
                    '            </includes>'
                )
            return match.group(0)

        def fix_excludes(match):
            nonlocal count
            inner = match.group(1)
            if any(elem in inner for elem in AOM2_SLOT_CHILD_ELEMENTS):
                count += 1
                return (
                    '<excludes>\n'
                    '              <string_expression>archetype_id/value matches {/.*/ }</string_expression>\n'
                    '            </excludes>'
                )
            return match.group(0)

        xml_str = re.sub(
            r'<includes>(.*?)</includes>',
            fix_includes,
            xml_str,
            flags=re.DOTALL
        )

        xml_str = re.sub(
            r'<excludes>(.*?)</excludes>',
            fix_excludes,
            xml_str,
            flags=re.DOTALL
        )

        return xml_str, count

    modified, slot_fixes = replace_slot_assertions(modified)
    if slot_fixes > 0:
        changes.append(f"AOM 2 slot-expressies → OPT 1.4 string_expression ({slot_fixes}×)")

    # === Fix 4: Remove any remaining AOM 2-only elements at top level ===
    # Some elements like <rmOverlay>, <terminology_extracts> may appear
    for elem_name in ['rmOverlay', 'rm_overlay', 'terminology_extracts']:
        pattern = rf'<{elem_name}\b[^>]*>.*?</{elem_name}\s*>'
        if re.search(pattern, modified, re.DOTALL):
            modified = re.sub(pattern, '', modified, flags=re.DOTALL)
            changes.append(f"Verwijderd: <{elem_name}>")

    # === Fix 5: Clean up AOM 2 xsi:type values that don't exist in OPT 1.4 ===
    # Map AOM 2 types to OPT 1.4 equivalents where needed
    type_mappings = {
        # These are typically fine as-is in OPT 1.4:
        # C_COMPLEX_OBJECT, C_ARCHETYPE_ROOT, ARCHETYPE_SLOT,
        # C_ATTRIBUTE, C_PRIMITIVE_OBJECT, C_TERMINOLOGY_CODE
    }
    for aom2_type, opt14_type in type_mappings.items():
        old = f'xsi:type="{aom2_type}"'
        new = f'xsi:type="{opt14_type}"'
        if old in modified:
            modified = modified.replace(old, new)
            changes.append(f"xsi:type {aom2_type} → {opt14_type}")

    # === Fix 6: Remove empty lines left by removals ===
    modified = re.sub(r'\n\s*\n\s*\n', '\n\n', modified)

    # Write result
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(modified)

    if changes:
        for change in changes:
            print(f"    ✓ {change}")
        print(f"    → Bijgewerkt (backup: {backup.name})")
    else:
        print(f"    ✓ Geen wijzigingen nodig")
        # Remove unnecessary backup
        backup.unlink()

    return True


def validate_basic(filepath):
    """Basic XML well-formedness check."""
    try:
        ET.parse(filepath)
        return True
    except ET.ParseError as e:
        print(f"    ✗ XML parse error na fix: {e}")
        return False


def main():
    if len(sys.argv) < 2:
        print("Gebruik: python3 scripts/fix_opt14.py <pad-naar-opt-of-directory>")
        print("  Voorbeeld: python3 scripts/fix_opt14.py opts/")
        sys.exit(1)

    target = Path(sys.argv[1])

    print("=== Sensire OpenEHR — OPT 1.4 Fixer ===")
    print(f"Doel: {target.absolute()}")

    if target.is_dir():
        opt_files = sorted(target.glob("*.opt"))
    elif target.is_file():
        opt_files = [target]
    else:
        print(f"FOUT: {target} bestaat niet")
        sys.exit(1)

    if not opt_files:
        print("Geen .opt bestanden gevonden")
        sys.exit(1)

    success = 0
    failed = 0

    for opt_file in opt_files:
        try:
            if fix_opt14(opt_file):
                if validate_basic(opt_file):
                    print(f"    ✓ XML well-formed")
                    success += 1
                else:
                    print(f"    ✗ XML NIET well-formed — herstel van backup")
                    backup = opt_file.with_suffix('.opt.bak')
                    if backup.exists():
                        shutil.copy2(backup, opt_file)
                    failed += 1
        except Exception as e:
            print(f"    ✗ FOUT: {e}")
            failed += 1

    print(f"\n=== Resultaat ===")
    print(f"  Gelukt:  {success}")
    print(f"  Mislukt: {failed}")

    if failed > 0:
        sys.exit(1)


if __name__ == '__main__':
    main()
