#!/usr/bin/env python3
"""
fix_opt14.py — Transform Archie 3.x AOM 2 OPT output to valid OPT 1.4 XML
that EHRbase 2.x accepts.

Fixes:
1. Root element → <template xmlns="http://schemas.openehr.org/v1">
2. Namespace: default ns instead of ns2: prefix
3. Add required OPT 1.4 header elements: <language>, <template_id>, <concept>
4. Strip AOM 2 slot expressions → OPT 1.4 string_expression
5. Remove AOM 2-only attributes (is_differential, is_generated)
"""

import sys
import re
import shutil
from pathlib import Path
import xml.etree.ElementTree as ET


NS_OPENEHR = "http://schemas.openehr.org/v1"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"

AOM2_SLOT_MARKERS = ['binaryOperator', 'unaryOperator', 'constraint',
                     'modelReference', 'operatorDefBuiltin']


def fix_opt14(filepath):
    """Fix a single OPT file from Archie AOM 2 output to OPT 1.4."""
    print(f"\n  Verwerken: {filepath.name}")

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    changes = []
    modified = content

    # === Step 1: Fix root element name ===
    for variant in [r'<operational_template\b', r'<operationaltemplate\b',
                    r'<operationalTemplate\b', r'<OperationalTemplate\b']:
        if re.search(variant, modified, re.IGNORECASE):
            modified = re.sub(variant, '<template', modified, count=1, flags=re.IGNORECASE)
            changes.append("Root element → <template>")
            break

    for variant in [r'</operational_template\s*>', r'</operationaltemplate\s*>',
                    r'</operationalTemplate\s*>', r'</OperationalTemplate\s*>']:
        if re.search(variant, modified, re.IGNORECASE):
            modified = re.sub(variant, '</template>', modified, count=1, flags=re.IGNORECASE)
            break

    # === Step 2: Fix namespace ===
    prefix_match = re.search(r'xmlns:(ns\d+)="' + re.escape(NS_OPENEHR) + '"', modified)
    if prefix_match:
        prefix = prefix_match.group(1)
        modified = re.sub(r'\s*xmlns:' + prefix + '="' + re.escape(NS_OPENEHR) + '"', '', modified)
        modified = re.sub(r'<' + prefix + ':', '<', modified)
        modified = re.sub(r'</' + prefix + ':', '</', modified)
        changes.append(f"Verwijderd namespace prefix {prefix}:")

    if f'xmlns="{NS_OPENEHR}"' not in modified:
        modified = re.sub(r'<template\b', f'<template xmlns="{NS_OPENEHR}"', modified, count=1)
        changes.append(f"Default namespace → {NS_OPENEHR}")

    if f'xmlns:xsi="{NS_XSI}"' not in modified:
        modified = re.sub(
            r'<template\b([^>]*?)>',
            lambda m: f'<template{m.group(1)} xmlns:xsi="{NS_XSI}">',
            modified, count=1
        )

    # === Step 3: Consolidate scattered xmlns:xsi declarations ===
    xsi_decl = f'xmlns:xsi="{NS_XSI}"'
    xsi_count = modified.count(xsi_decl)
    if xsi_count > 1:
        modified = modified.replace(f' {xsi_decl}', '')
        modified = re.sub(
            r'<template\b([^>]*?)>',
            lambda m: f'<template{m.group(1)} {xsi_decl}>',
            modified, count=1
        )
        changes.append(f"Geconsolideerd: {xsi_count} xmlns:xsi → 1")

    # === Step 4: Add missing OPT 1.4 header elements ===
    # EHRbase requires: <language>, <description>, <template_id>, <concept>, <definition>
    # Archie gives us: <description>, <original_language>, <archetype_id>, <definition>

    # Extract info we need from existing elements
    # Get language code from <original_language>
    lang_match = re.search(
        r'<original_language>\s*<terminology_id>([^<]+)</terminology_id>\s*<code_string>([^<]+)</code_string>\s*</original_language>',
        modified, re.DOTALL
    )
    lang_terminology = lang_match.group(1) if lang_match else "ISO_639-1"
    lang_code = lang_match.group(2) if lang_match else "nl"

    # Get concept_id from <archetype_id>
    concept_match = re.search(r'<archetype_id\s+concept_id="([^"]*)"', modified)
    concept_id = concept_match.group(1) if concept_match else filepath.stem

    # Get template_id from the archetype_id (full archetype HRID)
    # Build it from the archetype_id attributes
    aid_match = re.search(
        r'<archetype_id\s+'
        r'concept_id="([^"]*)"\s+'
        r'rm_publisher="([^"]*)"\s+'
        r'rm_package="([^"]*)"\s+'
        r'rm_class="([^"]*)"\s+'
        r'release_version="([^"]*)"',
        modified
    )
    if aid_match:
        template_id_value = f"{aid_match.group(2)}-{aid_match.group(3)}-{aid_match.group(4)}.{aid_match.group(1)}.v{aid_match.group(5).split('.')[0]}"
    else:
        template_id_value = concept_id

    # Build the language block
    language_block = f"""    <language>
        <terminology_id>
            <value>{lang_terminology}</value>
        </terminology_id>
        <code_string>{lang_code}</code_string>
    </language>"""

    # Build template_id block
    template_id_block = f"""    <template_id>
        <value>{template_id_value}</value>
    </template_id>"""

    # Build concept block
    concept_block = f"""    <concept>{concept_id}</concept>"""

    # Now insert these elements in the correct order
    # OPT 1.4 order: <language>, <description>, <template_id>, <concept>, <definition>

    # Add <language> right after <template ...> opening tag if not present
    if '<language>' not in modified.split('<description>')[0]:
        modified = re.sub(
            r'(<template[^>]*>)\s*\n',
            lambda m: f'{m.group(1)}\n{language_block}\n',
            modified, count=1
        )
        changes.append(f"Toegevoegd: <language> ({lang_code})")

    # Add <template_id> and <concept> after </description> and before <definition>
    # First, remove <original_language> (redundant with <language>)
    modified = re.sub(
        r'\s*<original_language>.*?</original_language>',
        '',
        modified, flags=re.DOTALL
    )

    # Remove the AOM 2 style <archetype_id ... /> (single-element with attributes)
    # and <parent_archetype_id> — these are replaced by template_id
    archetype_id_removed = False
    if re.search(r'<archetype_id\s+concept_id=', modified):
        modified = re.sub(r'\s*<archetype_id\s+[^/]*/>', '', modified)
        archetype_id_removed = True
    if '<parent_archetype_id>' in modified:
        modified = re.sub(r'\s*<parent_archetype_id>[^<]*</parent_archetype_id>', '', modified)

    # Insert template_id and concept before <definition>
    if '<template_id>' not in modified:
        modified = re.sub(
            r'(\s*)(<definition\b)',
            lambda m: f'\n{template_id_block}\n{concept_block}\n{m.group(1)}{m.group(2)}',
            modified, count=1
        )
        changes.append(f"Toegevoegd: <template_id> ({template_id_value})")
        changes.append(f"Toegevoegd: <concept> ({concept_id})")

    # === Step 5: Fix AOM 2 slot expressions ===
    def fix_slot_block(match):
        tag = match.group(1)
        inner = match.group(2)
        if any(marker in inner for marker in AOM2_SLOT_MARKERS):
            return (
                f'<{tag}>\n'
                f'                <string_expression>archetype_id/value matches {{/.*/}}</string_expression>\n'
                f'              </{tag}>'
            )
        return match.group(0)

    modified, slot_count = re.subn(
        r'<(includes|excludes)>(.*?)</\1>',
        fix_slot_block,
        modified,
        flags=re.DOTALL
    )
    if slot_count > 0:
        changes.append(f"AOM 2 slot-expressies → OPT 1.4 ({slot_count}×)")

    # === Step 6: Remove AOM 2-only elements ===
    for elem_name in ['rmOverlay', 'rm_overlay', 'terminology_extracts']:
        pattern = rf'\s*<{elem_name}\b[^>]*>.*?</{elem_name}\s*>'
        if re.search(pattern, modified, re.DOTALL):
            modified = re.sub(pattern, '', modified, flags=re.DOTALL)
            changes.append(f"Verwijderd: <{elem_name}>")

    # === Step 7: Remove AOM 2-only attributes ===
    for attr in ['is_differential', 'is_generated']:
        if attr in modified:
            modified = re.sub(rf'\s*{attr}="[^"]*"', '', modified)
            changes.append(f"Verwijderd attribuut: {attr}")

    # === Step 8: Clean up whitespace ===
    modified = re.sub(r'\n\s*\n\s*\n', '\n\n', modified)

    # === Write result ===
    backup = filepath.with_suffix('.opt.bak')
    shutil.copy2(filepath, backup)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(modified)

    if changes:
        for c in changes:
            print(f"    ✓ {c}")
        print(f"    → Bijgewerkt (backup: {backup.name})")
    else:
        print(f"    ✓ Geen wijzigingen nodig")
        backup.unlink()

    return True


def validate_wellformed(filepath):
    """Check XML is well-formed."""
    try:
        ET.parse(filepath)
        print(f"    ✓ XML well-formed")
        return True
    except ET.ParseError as e:
        print(f"    ✗ XML parse error: {e}")
        return False


def main():
    if len(sys.argv) < 2:
        print("Gebruik: python3 scripts/fix_opt14.py <pad-naar-opt-of-directory>")
        sys.exit(1)

    target = Path(sys.argv[1])
    print("=== Sensire OpenEHR — OPT 1.4 Fixer ===")
    print(f"Doel: {target.absolute()}")

    if target.is_dir():
        opt_files = sorted(target.glob("*.opt"))
    elif target.is_file():
        opt_files = [target]
    else:
        print(f"FOUT: {target} bestaat niet")
        sys.exit(1)

    if not opt_files:
        print("Geen .opt bestanden gevonden")
        sys.exit(1)

    success = 0
    failed = 0

    for f in opt_files:
        try:
            fix_opt14(f)
            if validate_wellformed(f):
                success += 1
            else:
                bak = f.with_suffix('.opt.bak')
                if bak.exists():
                    shutil.copy2(bak, f)
                    print(f"    → Hersteld van backup")
                failed += 1
        except Exception as e:
            print(f"    ✗ FOUT: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n=== Resultaat ===")
    print(f"  Gelukt:  {success}")
    print(f"  Mislukt: {failed}")

    if failed > 0:
        sys.exit(1)


if __name__ == '__main__':
    main()
